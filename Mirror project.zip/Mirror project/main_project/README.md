This is a reference code. If you want to run it, you need to modify the paths of the pre-trained model and data set in the code to your own paths.

Run the open_clip_main\open_clip_main\src\training\main.py file
All adjustable parameters are in this file
