import logging
import os
import multiprocessing
import subprocess
import time
import fsspec
import torch
import matplotlib.pyplot as plt
from tqdm import tqdm

def generate_part_joints(S1_hat, target_con, S1_hat_h36m, target_con_h36m):
    # 对以上的姿势1和姿势2进行画图确认
    print()

def double_view_vertice_plot(S1_hat,target,S1_hat_vertice,target_vertice,is_target):
    # 对以上的姿势1和姿势2进行画图确认
    if(is_target):
        poses_group1 = target
    else:
        poses_group1 = S1_hat
    xs1, xs2, xs3, xs4, xs5, xs6, xs7, xs8, xs9, xs10, xs11, xs12, xs13, xs14 = [poses_group1[0][13, 0],
                                                                                 poses_group1[0][12, 0]], [
                                                                                    poses_group1[0][12, 0],
                                                                                    poses_group1[0][9, 0]], [
                                                                                    poses_group1[0][12, 0],
                                                                                    poses_group1[0][8, 0]], [
                                                                                    poses_group1[0][9, 0],
                                                                                    poses_group1[0][10, 0]], [
                                                                                    poses_group1[0][10, 0],
                                                                                    poses_group1[0][11, 0]], [
                                                                                    poses_group1[0][8, 0],
                                                                                    poses_group1[0][7, 0]], [
                                                                                    poses_group1[0][7, 0],
                                                                                    poses_group1[0][6, 0]], [
                                                                                    poses_group1[0][8, 0],
                                                                                    poses_group1[0][2, 0]], [
                                                                                    poses_group1[0][9, 0],
                                                                                    poses_group1[0][3, 0]], [
                                                                                    poses_group1[0][2, 0],
                                                                                    poses_group1[0][3, 0]], [
                                                                                    poses_group1[0][2, 0],
                                                                                    poses_group1[0][1, 0]], [
                                                                                    poses_group1[0][1, 0],
                                                                                    poses_group1[0][0, 0]], [
                                                                                    poses_group1[0][3, 0],
                                                                                    poses_group1[0][4, 0]], [
                                                                                    poses_group1[0][4, 0],
                                                                                    poses_group1[0][5, 0]]
    ys1, ys2, ys3, ys4, ys5, ys6, ys7, ys8, ys9, ys10, ys11, ys12, ys13, ys14 = [poses_group1[0][13, 1],
                                                                                 poses_group1[0][12, 1]], [
                                                                                    poses_group1[0][12, 1],
                                                                                    poses_group1[0][9, 1]], [
                                                                                    poses_group1[0][12, 1],
                                                                                    poses_group1[0][8, 1]], [
                                                                                    poses_group1[0][9, 1],
                                                                                    poses_group1[0][10, 1]], [
                                                                                    poses_group1[0][10, 1],
                                                                                    poses_group1[0][11, 1]], [
                                                                                    poses_group1[0][8, 1],
                                                                                    poses_group1[0][7, 1]], [
                                                                                    poses_group1[0][7, 1],
                                                                                    poses_group1[0][6, 1]], [
                                                                                    poses_group1[0][8, 1],
                                                                                    poses_group1[0][2, 1]], [
                                                                                    poses_group1[0][9, 1],
                                                                                    poses_group1[0][3, 1]], [
                                                                                    poses_group1[0][2, 1],
                                                                                    poses_group1[0][3, 1]], [
                                                                                    poses_group1[0][2, 1],
                                                                                    poses_group1[0][1, 1]], [
                                                                                    poses_group1[0][1, 1],
                                                                                    poses_group1[0][0, 1]], [
                                                                                    poses_group1[0][3, 1],
                                                                                    poses_group1[0][4, 1]], [
                                                                                    poses_group1[0][4, 1],
                                                                                    poses_group1[0][5, 1]]
    zs1, zs2, zs3, zs4, zs5, zs6, zs7, zs8, zs9, zs10, zs11, zs12, zs13, zs14 = [poses_group1[0][13, 2],
                                                                                 poses_group1[0][12, 2]], [
                                                                                    poses_group1[0][12, 2],
                                                                                    poses_group1[0][9, 2]], [
                                                                                    poses_group1[0][12, 2],
                                                                                    poses_group1[0][8, 2]], [
                                                                                    poses_group1[0][9, 2],
                                                                                    poses_group1[0][10, 2]], [
                                                                                    poses_group1[0][10, 2],
                                                                                    poses_group1[0][11, 2]], [
                                                                                    poses_group1[0][8, 2],
                                                                                    poses_group1[0][7, 2]], [
                                                                                    poses_group1[0][7, 2],
                                                                                    poses_group1[0][6, 2]], [
                                                                                    poses_group1[0][8, 2],
                                                                                    poses_group1[0][2, 2]], [
                                                                                    poses_group1[0][9, 2],
                                                                                    poses_group1[0][3, 2]], [
                                                                                    poses_group1[0][2, 2],
                                                                                    poses_group1[0][3, 2]], [
                                                                                    poses_group1[0][2, 2],
                                                                                    poses_group1[0][1, 2]], [
                                                                                    poses_group1[0][1, 2],
                                                                                    poses_group1[0][0, 2]], [
                                                                                    poses_group1[0][3, 2],
                                                                                    poses_group1[0][4, 2]], [
                                                                                    poses_group1[0][4, 2],
                                                                                    poses_group1[0][5, 2]]
    fig = plt.figure()
    ax = fig.add_axes((0, 0, 1, 1), projection='3d')
    ax.plot(xs1, ys1, zs1, c='blue', marker='o')
    ax.plot(xs2, ys2, zs2, c='blue', marker='o')
    ax.plot(xs3, ys3, zs3, c='blue', marker='o')
    ax.plot(xs4, ys4, zs4, c='blue', marker='o')
    ax.plot(xs5, ys5, zs5, c='blue', marker='o')
    ax.plot(xs6, ys6, zs6, c='blue', marker='o')
    ax.plot(xs7, ys7, zs7, c='blue', marker='o')
    ax.plot(xs8, ys8, zs8, c='blue', marker='o')
    ax.plot(xs9, ys9, zs9, c='blue', marker='o')
    ax.plot(xs10, ys10, zs10, c='blue', marker='o')
    ax.plot(xs11, ys11, zs11, c='blue', marker='o')
    ax.plot(xs12, ys12, zs12, c='blue', marker='o')
    ax.plot(xs13, ys13, zs13, c='blue', marker='o')
    ax.plot(xs14, ys14, zs14, c='blue', marker='o')
    # plt.show()
    # 以下的程序用来
    if (is_target):
        poses_group1 = target_vertice
    else:
        poses_group1 = S1_hat_vertice
    # 对以上的姿势1和姿势2进行画图确认
    # fig = plt.figure()
    # ax = fig.add_axes((0, 0, 1, 1), projection='3d')
    for index in range(len(poses_group1)):
        if(poses_group1[index][0] == 0 and poses_group1[index][1] == 0 and poses_group1[index][2] == 0):
            continue
        else:
            ax.plot(poses_group1[index][0], poses_group1[index][1], poses_group1[index][2], c='red',
                    marker='.')
            # ax.plot(poses_group2[0][index][0], poses_group2[0][index][1], poses_group2[0][index][2], c='red',
            #         marker='.')
    plt.show()

def double_view_sample_plot(evaluation_accumulators_pred_j3d,evaluation_accumulators_target_j3d):
    # pred_j3ds_group1, target_j3ds_group1, camera_para_group1, box_center_group1, box_scaler_group1 = evaluation_accumulators_pred_j3d[1]
    # pred_j3ds_group2, target_j3ds_group2, camera_para_group2, box_center_group2, box_scaler_group2 = evaluation_accumulators_pred_j3d[2]
    # for index in range(len(evaluation_accumulators_pred_j3d)):
    # pred_j3ds = evaluation_accumulators_pred_j3d[index]
    # target_j3ds = evaluation_accumulators_target_j3d[index]
    # camera_para = evaluation_accumulators_camera_para[index]
    # box_center = evaluation_accumulators_center[index]
    # box_scaler = evaluation_accumulators_scaler[index]
    # 以下的程序用来
    poses_group1 = evaluation_accumulators_pred_j3d
    poses_group2 = evaluation_accumulators_target_j3d
    # for id_utem in range(len(target_j3ds_group1)):
    #     poses_group1.append(camera_to_world_frame(pred_j3ds_group1[id_utem], camera_para_group1[id_utem][0]['R'],camera_para_group1[id_utem][0]['T']))
    #     poses_group2.append(camera_to_world_frame(pred_j3ds_group2[id_utem], camera_para_group2[id_utem][0]['R'],camera_para_group2[id_utem][0]['T']))

    # 对以上的姿势1和姿势2进行画图确认
    xs1, xs2, xs3, xs4, xs5, xs6, xs7, xs8, xs9, xs10, xs11, xs12, xs13, xs14 = [poses_group1[0][13, 0],
                                                                                 poses_group1[0][12, 0]], [
                                                                                    poses_group1[0][12, 0],
                                                                                    poses_group1[0][9, 0]], [
                                                                                    poses_group1[0][12, 0],
                                                                                    poses_group1[0][8, 0]], [
                                                                                    poses_group1[0][9, 0],
                                                                                    poses_group1[0][10, 0]], [
                                                                                    poses_group1[0][10, 0],
                                                                                    poses_group1[0][11, 0]], [
                                                                                    poses_group1[0][8, 0],
                                                                                    poses_group1[0][7, 0]], [
                                                                                    poses_group1[0][7, 0],
                                                                                    poses_group1[0][6, 0]], [
                                                                                    poses_group1[0][8, 0],
                                                                                    poses_group1[0][2, 0]], [
                                                                                    poses_group1[0][9, 0],
                                                                                    poses_group1[0][3, 0]], [
                                                                                    poses_group1[0][2, 0],
                                                                                    poses_group1[0][3, 0]], [
                                                                                    poses_group1[0][2, 0],
                                                                                    poses_group1[0][1, 0]], [
                                                                                    poses_group1[0][1, 0],
                                                                                    poses_group1[0][0, 0]], [
                                                                                    poses_group1[0][3, 0],
                                                                                    poses_group1[0][4, 0]], [
                                                                                    poses_group1[0][4, 0],
                                                                                    poses_group1[0][5, 0]]
    ys1, ys2, ys3, ys4, ys5, ys6, ys7, ys8, ys9, ys10, ys11, ys12, ys13, ys14 = [poses_group1[0][13, 1],
                                                                                 poses_group1[0][12, 1]], [
                                                                                    poses_group1[0][12, 1],
                                                                                    poses_group1[0][9, 1]], [
                                                                                    poses_group1[0][12, 1],
                                                                                    poses_group1[0][8, 1]], [
                                                                                    poses_group1[0][9, 1],
                                                                                    poses_group1[0][10, 1]], [
                                                                                    poses_group1[0][10, 1],
                                                                                    poses_group1[0][11, 1]], [
                                                                                    poses_group1[0][8, 1],
                                                                                    poses_group1[0][7, 1]], [
                                                                                    poses_group1[0][7, 1],
                                                                                    poses_group1[0][6, 1]], [
                                                                                    poses_group1[0][8, 1],
                                                                                    poses_group1[0][2, 1]], [
                                                                                    poses_group1[0][9, 1],
                                                                                    poses_group1[0][3, 1]], [
                                                                                    poses_group1[0][2, 1],
                                                                                    poses_group1[0][3, 1]], [
                                                                                    poses_group1[0][2, 1],
                                                                                    poses_group1[0][1, 1]], [
                                                                                    poses_group1[0][1, 1],
                                                                                    poses_group1[0][0, 1]], [
                                                                                    poses_group1[0][3, 1],
                                                                                    poses_group1[0][4, 1]], [
                                                                                    poses_group1[0][4, 1],
                                                                                    poses_group1[0][5, 1]]
    zs1, zs2, zs3, zs4, zs5, zs6, zs7, zs8, zs9, zs10, zs11, zs12, zs13, zs14 = [poses_group1[0][13, 2],
                                                                                 poses_group1[0][12, 2]], [
                                                                                    poses_group1[0][12, 2],
                                                                                    poses_group1[0][9, 2]], [
                                                                                    poses_group1[0][12, 2],
                                                                                    poses_group1[0][8, 2]], [
                                                                                    poses_group1[0][9, 2],
                                                                                    poses_group1[0][10, 2]], [
                                                                                    poses_group1[0][10, 2],
                                                                                    poses_group1[0][11, 2]], [
                                                                                    poses_group1[0][8, 2],
                                                                                    poses_group1[0][7, 2]], [
                                                                                    poses_group1[0][7, 2],
                                                                                    poses_group1[0][6, 2]], [
                                                                                    poses_group1[0][8, 2],
                                                                                    poses_group1[0][2, 2]], [
                                                                                    poses_group1[0][9, 2],
                                                                                    poses_group1[0][3, 2]], [
                                                                                    poses_group1[0][2, 2],
                                                                                    poses_group1[0][3, 2]], [
                                                                                    poses_group1[0][2, 2],
                                                                                    poses_group1[0][1, 2]], [
                                                                                    poses_group1[0][1, 2],
                                                                                    poses_group1[0][0, 2]], [
                                                                                    poses_group1[0][3, 2],
                                                                                    poses_group1[0][4, 2]], [
                                                                                    poses_group1[0][4, 2],
                                                                                    poses_group1[0][5, 2]]
    fig = plt.figure()
    ax = fig.add_axes((0, 0, 1, 1), projection='3d')

    ax.plot(xs1, ys1, zs1, c='blue', marker='o')
    ax.plot(xs2, ys2, zs2, c='blue', marker='o')
    ax.plot(xs3, ys3, zs3, c='blue', marker='o')
    ax.plot(xs4, ys4, zs4, c='blue', marker='o')
    ax.plot(xs5, ys5, zs5, c='blue', marker='o')
    ax.plot(xs6, ys6, zs6, c='blue', marker='o')
    ax.plot(xs7, ys7, zs7, c='blue', marker='o')
    ax.plot(xs8, ys8, zs8, c='blue', marker='o')
    ax.plot(xs9, ys9, zs9, c='blue', marker='o')
    ax.plot(xs10, ys10, zs10, c='blue', marker='o')
    ax.plot(xs11, ys11, zs11, c='blue', marker='o')
    ax.plot(xs12, ys12, zs12, c='blue', marker='o')
    ax.plot(xs13, ys13, zs13, c='blue', marker='o')
    ax.plot(xs14, ys14, zs14, c='blue', marker='o')
    # plt.show()

    xs1, xs2, xs3, xs4, xs5, xs6, xs7, xs8, xs9, xs10, xs11, xs12, xs13, xs14 = [poses_group2[0][13, 0],
                                                                                 poses_group2[0][12, 0]], [
                                                                                    poses_group2[0][12, 0],
                                                                                    poses_group2[0][9, 0]], [
                                                                                    poses_group2[0][12, 0],
                                                                                    poses_group2[0][8, 0]], [
                                                                                    poses_group2[0][9, 0],
                                                                                    poses_group2[0][10, 0]], [
                                                                                    poses_group2[0][10, 0],
                                                                                    poses_group2[0][11, 0]], [
                                                                                    poses_group2[0][8, 0],
                                                                                    poses_group2[0][7, 0]], [
                                                                                    poses_group2[0][7, 0],
                                                                                    poses_group2[0][6, 0]], [
                                                                                    poses_group2[0][8, 0],
                                                                                    poses_group2[0][2, 0]], [
                                                                                    poses_group2[0][9, 0],
                                                                                    poses_group2[0][3, 0]], [
                                                                                    poses_group2[0][2, 0],
                                                                                    poses_group2[0][3, 0]], [
                                                                                    poses_group2[0][2, 0],
                                                                                    poses_group2[0][1, 0]], [
                                                                                    poses_group2[0][1, 0],
                                                                                    poses_group2[0][0, 0]], [
                                                                                    poses_group2[0][3, 0],
                                                                                    poses_group2[0][4, 0]], [
                                                                                    poses_group2[0][4, 0],
                                                                                    poses_group2[0][5, 0]]
    ys1, ys2, ys3, ys4, ys5, ys6, ys7, ys8, ys9, ys10, ys11, ys12, ys13, ys14 = [poses_group2[0][13, 1],
                                                                                 poses_group2[0][12, 1]], [
                                                                                    poses_group2[0][12, 1],
                                                                                    poses_group2[0][9, 1]], [
                                                                                    poses_group2[0][12, 1],
                                                                                    poses_group2[0][8, 1]], [
                                                                                    poses_group2[0][9, 1],
                                                                                    poses_group2[0][10, 1]], [
                                                                                    poses_group2[0][10, 1],
                                                                                    poses_group2[0][11, 1]], [
                                                                                    poses_group2[0][8, 1],
                                                                                    poses_group2[0][7, 1]], [
                                                                                    poses_group2[0][7, 1],
                                                                                    poses_group2[0][6, 1]], [
                                                                                    poses_group2[0][8, 1],
                                                                                    poses_group2[0][2, 1]], [
                                                                                    poses_group2[0][9, 1],
                                                                                    poses_group2[0][3, 1]], [
                                                                                    poses_group2[0][2, 1],
                                                                                    poses_group2[0][3, 1]], [
                                                                                    poses_group2[0][2, 1],
                                                                                    poses_group2[0][1, 1]], [
                                                                                    poses_group2[0][1, 1],
                                                                                    poses_group2[0][0, 1]], [
                                                                                    poses_group2[0][3, 1],
                                                                                    poses_group2[0][4, 1]], [
                                                                                    poses_group2[0][4, 1],
                                                                                    poses_group2[0][5, 1]]
    zs1, zs2, zs3, zs4, zs5, zs6, zs7, zs8, zs9, zs10, zs11, zs12, zs13, zs14 = [poses_group2[0][13, 2],
                                                                                 poses_group2[0][12, 2]], [
                                                                                    poses_group2[0][12, 2],
                                                                                    poses_group2[0][9, 2]], [
                                                                                    poses_group2[0][12, 2],
                                                                                    poses_group2[0][8, 2]], [
                                                                                    poses_group2[0][9, 2],
                                                                                    poses_group2[0][10, 2]], [
                                                                                    poses_group2[0][10, 2],
                                                                                    poses_group2[0][11, 2]], [
                                                                                    poses_group2[0][8, 2],
                                                                                    poses_group2[0][7, 2]], [
                                                                                    poses_group2[0][7, 2],
                                                                                    poses_group2[0][6, 2]], [
                                                                                    poses_group2[0][8, 2],
                                                                                    poses_group2[0][2, 2]], [
                                                                                    poses_group2[0][9, 2],
                                                                                    poses_group2[0][3, 2]], [
                                                                                    poses_group2[0][2, 2],
                                                                                    poses_group2[0][3, 2]], [
                                                                                    poses_group2[0][2, 2],
                                                                                    poses_group2[0][1, 2]], [
                                                                                    poses_group2[0][1, 2],
                                                                                    poses_group2[0][0, 2]], [
                                                                                    poses_group2[0][3, 2],
                                                                                    poses_group2[0][4, 2]], [
                                                                                    poses_group2[0][4, 2],
                                                                                    poses_group2[0][5, 2]]
    # fig = plt.figure()
    # ax = fig.add_axes((0, 0, 1, 1), projection='3d')

    ax.plot(xs1, ys1, zs1, c='red', marker='o')
    ax.plot(xs2, ys2, zs2, c='red', marker='o')
    ax.plot(xs3, ys3, zs3, c='red', marker='o')
    ax.plot(xs4, ys4, zs4, c='red', marker='o')
    ax.plot(xs5, ys5, zs5, c='red', marker='o')
    ax.plot(xs6, ys6, zs6, c='red', marker='o')
    ax.plot(xs7, ys7, zs7, c='red', marker='o')
    ax.plot(xs8, ys8, zs8, c='red', marker='o')
    ax.plot(xs9, ys9, zs9, c='red', marker='o')
    ax.plot(xs10, ys10, zs10, c='red', marker='o')
    ax.plot(xs11, ys11, zs11, c='red', marker='o')
    ax.plot(xs12, ys12, zs12, c='red', marker='o')
    ax.plot(xs13, ys13, zs13, c='red', marker='o')
    ax.plot(xs14, ys14, zs14, c='red', marker='o')
    plt.show()

def remote_sync_s3(local_dir, remote_dir):
    # skip epoch_latest which can change during sync.
    result = subprocess.run(["aws", "s3", "sync", local_dir, remote_dir, '--exclude', '*epoch_latest.pt'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        logging.error(f"Error: Failed to sync with S3 bucket {result.stderr.decode('utf-8')}")
        return False
        
    logging.info(f"Successfully synced with S3 bucket")
    return True

def remote_sync_fsspec(local_dir, remote_dir):
    # FIXME currently this is slow and not recommended. Look into speeding up.
    a = fsspec.get_mapper(local_dir)
    b = fsspec.get_mapper(remote_dir)

    for k in a:
        # skip epoch_latest which can change during sync.
        if 'epoch_latest.pt' in k:
            continue

        logging.info(f'Attempting to sync {k}')
        if k in b and len(a[k]) == len(b[k]):
            logging.debug(f'Skipping remote sync for {k}.')
            continue

        try:
            logging.info(f'Successful sync for {k}.')
            b[k] = a[k]
        except Exception as e:
            logging.info(f'Error during remote sync for {k}: {e}')
            return False

    return True

def remote_sync(local_dir, remote_dir, protocol):
    logging.info('Starting remote sync.')
    if protocol == 's3':
        return remote_sync_s3(local_dir, remote_dir)
    elif protocol == 'fsspec':
        return remote_sync_fsspec(local_dir, remote_dir)
    else:
        logging.error('Remote protocol not known')
        return False

def keep_running_remote_sync(sync_every, local_dir, remote_dir, protocol):
    while True:
        time.sleep(sync_every)
        remote_sync(local_dir, remote_dir, protocol)

def start_sync_process(sync_every, local_dir, remote_dir, protocol):
    p = multiprocessing.Process(target=keep_running_remote_sync, args=(sync_every, local_dir, remote_dir, protocol))
    return p

# Note: we are not currently using this save function.
def pt_save(pt_obj, file_path):
    of = fsspec.open(file_path, "wb")
    with of as f:
        torch.save(pt_obj, file_path)

def pt_load(file_path, map_location=None):
    if not file_path.startswith('/'):
        logging.info('Loading remote checkpoint, which may take a bit.')
    of = fsspec.open(file_path, "rb")
    with of as f:
        out = torch.load(f, map_location=map_location)
    return out

def check_exists(file_path):
    try:
        with fsspec.open(file_path):
            pass
    except FileNotFoundError:
        return False
    return True
