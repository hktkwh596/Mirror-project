import numpy as np
# from sklearn.metrics import f1_score, precision_recall_fscore_support
import matplotlib
import csv
# import tensorflow as tf
# import pandas as pd
import matplotlib.pyplot as plt
from numpy import exp, dot, zeros, dtype, float32 as REAL,\
    uint32, seterr, array, uint8, vstack, fromstring, sqrt,\
    empty, sum as np_sum, ones, logaddexp, log, outer

# #2D_JDR
x = [-0.2,-0.12,-0.04,0.0,0.04,0.12,0.2,0.28,0.36,0.44,0.52]  #x = [(x + 1)*10  for x in range(10 - 1)]
plt.ylim(-0.35, 1.16)  # 限定纵轴的范围
plt.xlim(-0.22, 0.54)
array1=[0.8,0.4,0.11,0,-0.09,-0.18,-0.15,-0.06,0.16,0.5,0.9]
array2=[1.14,0.6,0.17,0,-0.14,-0.31,-0.33,-0.25,0,0.34,0.83]
array3=[0,0,0,0,0,0,0,0,0,0,0]
# array4=[0,0.027,0,0.1985,0.278,0.162,0.369,0.542,0.5765,0.59]

plt.plot(x,array1, marker='', mec='r', mfc='w', label=u'mpjpe')#plt.plot(x,array1, marker='o', mec='r', mfc='r', label=u'origin model(Resnet-34)')
plt.plot(x,array2, marker='', mec='r', mfc='w', label=u'pa-mpjpe')
plt.plot(x,array3, c='k', label=u'error=0')
# plt.plot(x,array4, marker='^', mec='r', mfc='w', label=u'efficientnetv2')
plt.legend()  # 让图例生效
plt.xlabel(u"weight", fontsize=15)  # X轴标签
plt.ylabel("Optimize Increment", fontsize=15)  # Y轴标签plt.ylabel("Micro/Macro-F;samples;weighted;accuracy")
plt.title(u"MPI (sequence estimation)", fontsize=15)  # 标题#plt.title(u"wikipedia(treated)")
# plt.savefig('./1.jpg')
plt.show()
#
# # #macro
x = [-0.2,-0.12,-0.04,0,0.04,0.12,0.2,0.28,0.36,0.44,0.52,0.6,0.68,0.76,0.84]  #x = [(x + 1)*10  for x in range(10 - 1)]
plt.ylim(-0.71, 1.43)  # 限定纵轴的范围
plt.xlim(-0.22, 0.86)
array1=[0.85,0.46,0.14,0,-0.12,-0.3,-0.4,-0.42,-0.35,-0.22,0.01,0.28,0.64,0.97,1.41]#之前这里有错，第三个跟第四个重复了
array2=[1.06,0.59,0.18,0,-0.16,-0.43,-0.61,-0.69,-0.67,-0.59,-0.38,-0.14,0.26,0.64,1.16]
array3=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
plt.plot(x,array1, marker='', mec='r', mfc='w', label=u'mpjpe')
plt.plot(x,array2, marker='', mec='r', mfc='w', label=u'pa-mpjpe')
plt.plot(x,array3, c='k', label=u'error=0')
plt.legend()  # 让图例生效
plt.xlabel(u"weight", fontsize=15)  # X轴标签
plt.ylabel("Optimize Increment", fontsize=15)  # Y轴标签plt.ylabel("Micro/Macro-F;samples;weighted;accuracy")
plt.title(u"H36M (sequence estimation)", fontsize=15)  # 标题#plt.title(u"wikipedia(treated)")
# plt.savefig('./1.jpg')
plt.show()

#这个地方有误，x的值应该是1，3，5，7，9...
x = [-0.28,-0.2,-0.12,-0.04,0,0.04,0.12,0.2,0.28,0.36,0.44,0.52,0.6,0.68,0.76]  #x = [(x + 1)*10  for x in range(10 - 1)]
plt.ylim(-0.35, 1.73)  # 限定纵轴的范围
plt.xlim(-0.3, 0.78)
array1=[0.91,0.59,0.31,0.09,0,-0.08,-0.2,-0.28,-0.3,-0.29,-0.23,-0.08,0.02,0.31,0.52]
array2=[1.41,0.87,0.47,0.13,0,-0.11,-0.26,-0.33,-0.29,-0.16,-0.01,0.31,0.69,1.2,1.71]
array3=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
plt.plot(x,array1, marker='', mec='r', mfc='w', label=u'mpjpe')
plt.plot(x,array2, marker='', mec='r', mfc='w', label=u'pa-mpjpe')
plt.plot(x,array3, c='k', label=u'error=0')
plt.legend()  # 让图例生效
plt.xlabel(u"weight", fontsize=15)  # X轴标签
plt.ylabel("Optimize Increment", fontsize=15)  # Y轴标签plt.ylabel("Micro/Macro-F;samples;weighted;accuracy")
plt.title(u"3DPW (sequence estimation)", fontsize=15)  # 标题#plt.title(u"wikipedia(treated)")
# plt.savefig('./1.jpg')
plt.show()
#
# #



x = [-0.28,-0.2,-0.12,-0.04,0,0.04,0.12,0.2,0.28,0.36,0.44,0.52,0.6,0.68,0.76]  #x = [(x + 1)*10  for x in range(10 - 1)]
plt.ylim(-0.19, 0.74)  # 限定纵轴的范围
plt.xlim(-0.3, 0.78)
array1=[0.41,0.26,0.13,0.04,0,-0.03,-0.06,-0.07,-0.04,0.02,0.09,0.2,0.35,0.54,0.72]
array2=[0.68,0.42,0.23,0.07,0,-0.05,-0.13,-0.17,-0.17,-0.12,-0.05,0.1,0.26,0.5,0.68]
array3=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
# array4=[0,0.027,0,0.1985,0.278,0.162,0.369,0.542,0.5765,0.59]
plt.plot(x,array1, marker='', mec='r', mfc='w', label=u'mpjpe')#plt.plot(x,array1, marker='o', mec='r', mfc='r', label=u'origin model(Resnet-34)')
plt.plot(x,array2, marker='', mec='r', mfc='w', label=u'pa-mpjpe')
plt.plot(x,array3, c='k', label=u'error=0')
# plt.plot(x,array4, marker='^', mec='r', mfc='w', label=u'efficientnetv2')
plt.legend()  # 让图例生效
plt.xlabel(u"weight", fontsize=15)  # X轴标签
plt.ylabel("Optimize Increment", fontsize=15)  # Y轴标签plt.ylabel("Micro/Macro-F;samples;weighted;accuracy")
plt.title(u"MPI (single image estimation)", fontsize=15)  # 标题#plt.title(u"wikipedia(treated)")
# plt.savefig('./1.jpg')
plt.show()
#
# # #macro
x = [-0.28,-0.2,-0.12,-0.04,0,0.04,0.12,0.2,0.28,0.36,0.44,0.52,0.6,0.68,0.76,0.84,0.92,1,1.08,1.16,1.24,1.32,1.4]  #x = [(x + 1)*10  for x in range(10 - 1)]
plt.ylim(-0.94, 0.97)  # 限定纵轴的范围
plt.xlim(-0.3, 1.42)
array1=[0.6,0.4,0.22,0.07,0,-0.07,-0.18,-0.27,-0.36,-0.39,-0.43,-0.47,-0.44,-0.39,-0.33,-0.31,-0.21,-0.13,-0.01,0.08,0.29,0.46,0.63]#之前这里有错，第三个跟第四个重复了
array2=[0.95,0.64,0.36,0.11,0,-0.11,-0.29,-0.47,-0.64,-0.71,-0.85,-0.88,-0.9,-0.92,-0.84,-0.84,-0.69,-0.6,-0.52,-0.44,-0.19,0,0.26]
array3=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
plt.plot(x,array1, marker='', mec='r', mfc='w', label=u'mpjpe')
plt.plot(x,array2, marker='', mec='r', mfc='w', label=u'pa-mpjpe')
plt.plot(x,array3, c='k', label=u'error=0')
plt.legend()  # 让图例生效
plt.xlabel(u"weight", fontsize=15)  # X轴标签
plt.ylabel("Optimize Increment", fontsize=15)  # Y轴标签plt.ylabel("Micro/Macro-F;samples;weighted;accuracy")
plt.title(u"H36M (single image estimation)", fontsize=15)  # 标题#plt.title(u"wikipedia(treated)")
# plt.savefig('./1.jpg')
plt.show()

#这个地方有误，x的值应该是1，3，5，7，9...
x = [-0.28,-0.2,-0.12,-0.04,0,0.04,0.12,0.2,0.28,0.36,0.44,0.52,0.6,0.68,0.76,0.84,0.92,1,1.08,1.16,1.24,1.32,1.4]  #x = [(x + 1)*10  for x in range(10 - 1)]
plt.ylim(-0.84, 1.15)  # 限定纵轴的范围
plt.xlim(-0.3, 1.42)
array1=[0.67,0.45,0.25,0.08,0,-0.08,-0.21,-0.32,-0.42,-0.53,-0.56,-0.61,-0.66,-0.62,-0.61,-0.56,-0.5,-0.39,-0.33,-0.26,-0.03,0.06,0.21]
array2=[1.03,0.7,0.39,0.13,0,-0.12,-0.32,-0.48,-0.63,-0.76,-0.8,-0.79,-0.82,-0.77,-0.65,-0.56,-0.4,-0.17,-0.03,0.29,0.66,0.84,1.13]
array3=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
plt.plot(x,array1, marker='', mec='r', mfc='w', label=u'mpjpe')
plt.plot(x,array2, marker='', mec='r', mfc='w', label=u'pa-mpjpe')
plt.plot(x,array3, c='k', label=u'error=0')
plt.legend()  # 让图例生效
plt.xlabel(u"weight", fontsize=15)  # X轴标签
plt.ylabel("Optimize Increment", fontsize=15)  # Y轴标签plt.ylabel("Micro/Macro-F;samples;weighted;accuracy")
plt.title(u"3DPW (single image estimation)", fontsize=15)  # 标题#plt.title(u"wikipedia(treated)")
# plt.savefig('./1.jpg')
plt.show()