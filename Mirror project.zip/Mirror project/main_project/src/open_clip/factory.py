import json
# import logging
# import os
# import pathlib
import numpy as np
import re
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union
import torch
import colorsys
import os
import cv2
from tqdm import tqdm
# from .constants import OPENAI_DATASET_MEAN, OPENAI_DATASET_STD
from .model import CLIP, convert_weights_to_lp, convert_to_custom_text_state_dict,\
    resize_pos_embed
# from .coca_model import CoCa
from .loss import ClipLoss, CoCaLoss
# from .openai import load_openai_model
# from .pretrained import is_pretrained_cfg, get_pretrained_cfg, download_pretrained, list_pretrained_tags_by_model, download_pretrained_from_hf
from .transform import image_transform, AugmentationCfg
# from .tokenizer import HFTokenizer, tokenize
from VIBE_master_PaMIR.lib.utils.renderer import Renderer
from VIBE_master_PaMIR.lib.data_utils.img_utils import get_single_image_crop, convert_cvimg_to_tensor
from VIBE_master_PaMIR.lib.utils.demo_utils import (
    # download_youtube_clip,
    # smplify_runner,
    convert_crop_coords_to_orig_img,
    convert_crop_cam_to_orig_img,
    prepare_rendering_results,
    # video_to_images,
    # images_to_video,
    # download_ckpt,
)
from PIL import Image
from PIL import ImageEnhance
import matplotlib.pyplot as plt

HF_HUB_PREFIX = 'hf-hub:'
_MODEL_CONFIG_PATHS = [Path(__file__).parent / f"model_configs/"]
_MODEL_CONFIGS = {}  # directory (model_name: config) of model architecture configs

def error_curve_plot_1(origin_error,origin_enhan_error,origin_pa_error,origin_pa_enhan_error,joint_id,axis):
    plt.figure(figsize=(20, 10), dpi=100)
    game = range(len(origin_error))
    origin_error_ = origin_error[:,joint_id,axis]
    origin_enhan_error_ = origin_enhan_error[:, joint_id, axis]
    origin_pa_error_ = origin_pa_error[:, joint_id, axis]
    origin_pa_enhan_error_ = origin_pa_enhan_error[:, joint_id, axis]
    plt.plot(game, [0]*len(origin_pa_enhan_error_), c='black')
    plt.plot(game, origin_pa_error_, label = 'origin', c='green')
    plt.scatter(game, origin_pa_error_, label = 'origin', c='green')
    plt.plot(game, origin_pa_enhan_error_, label = 'mirror', c='red')
    plt.scatter(game, origin_pa_enhan_error_, label = 'mirror', c='red')
    plt.show()

def error_curve_plot_2(origin_pa_error,origin_pa_enhan_error,target,joint_id,axis):
    plt.figure(figsize=(20, 10), dpi=100)
    game = range(len(origin_error))
    origin_error_ = origin_error[:,joint_id,axis]
    origin_enhan_error_ = origin_enhan_error[:, joint_id, axis]
    origin_pa_error_ = origin_pa_error[:, joint_id, axis]
    origin_pa_enhan_error_ = origin_pa_enhan_error[:, joint_id, axis]
    plt.plot(game, [0]*len(origin_pa_enhan_error_), c='black')
    plt.plot(game, origin_pa_error_, c='green')
    plt.scatter(game, origin_pa_error_, c='green')
    plt.plot(game, origin_pa_enhan_error_, c='red')
    plt.scatter(game, origin_pa_enhan_error_, c='red')
    plt.show()
    print()
    2



def extra_feature(current_image, model_spin, bbox,is_flip):
    current_image_list = []
    for index in range(len(current_image)):
        img_fname_list = current_image[index].split('\\')
        # img_fname_part = img_fname_list[2] + '_enhancement'
        if('MPI' in current_image[index]):
            current_image_list.append('I:\\diskF' + '\\' + img_fname_list[1] + '\\' + img_fname_list[2] + '\\' + img_fname_list[3] + '\\' + img_fname_list[4])
        elif('H36M' in current_image[index]):
            current_image_list.append('I:\\diskF' + '\\' + img_fname_list[1] + '\\' + img_fname_list[2] + '\\' + img_fname_list[3])
        else:
            current_image_PATH = None
            for value_ in img_fname_list:
                if(current_image_PATH==None):
                    current_image_PATH = value_
                else:
                    current_image_PATH = current_image_PATH+'\\' + value_
            current_image_list.append(current_image_PATH)

        # img_fname_con = 'F' + current_image[index][1:]
        # img_fname_con_part = img_fname_con.split('\\')
        # current_image_list.append(img_fname_con_part[0] + "\\MPI-INF-3DHP(beifen_mask)_enhancement" + '\\' + img_fname_con_part[3] + '\\' + \
        #             img_fname_con_part[4])
    current_image = current_image_list


    features = []
    bbox = bbox.reshape(len(bbox)*len(bbox[0]),-1)
    if(is_flip):
        video_list = [cv2.flip(get_single_image_crop(image, [128, 128, 256, 256], scale=1.0), 1) for image, bbox in zip(current_image, bbox)]
    else:
        video_list = [get_single_image_crop(image, [128, 128, 256, 256], scale=1.0) for image, bbox in
                      zip(current_image, bbox)]
    # video_view = video_list[0].reshape(len(video_list[0][0]), len(video_list[0][0][0]), len(video_list[0]))
    # cv2.imwrite(os.path.join('C:\\Users\\Administrator\\Desktop', 'www.png'), video_list[0])
    for index in range(len(video_list)):
        video_list[index] = convert_cvimg_to_tensor(video_list[index]).unsqueeze(0)

    # video_list = [convert_cvimg_to_tensor(cv2.flip(get_single_image_crop('F' + image[1:], [128, 128, 256, 256], scale=1.0), 1)).unsqueeze(0) for image, bbox in
    #  zip(current_image, bbox)]

    video = torch.cat(video_list, dim=0).to('cuda')
    # pred = model_spin.feature_extractor(video)
    # features.append(pred)
    # exp = video[0]
    # video_view.reshape(len(exp[0][0]),len(exp),len(exp[0]))
    #这里增加一个图片翻转过程
    # img = cv2.imread(video)
    # for index in range(len(video)):
    #     video[index] = cv2.flip(video[index], 1)

    batch_size = len(bbox)
    with torch.no_grad():
        for index in range(0,len(video),batch_size):
            if (len(video) - index < batch_size):
                pred = model_spin.feature_extractor(video[index:])
                features.append(pred)
            else:
                pred = model_spin.feature_extractor(video[index:index+batch_size])
                features.append(pred)

        features = torch.cat(features, dim=0)
    return features


def convert_3d_to_image(preds, cam, image_name, bbox):
    vibe_results = {}
    seqlen = len(preds[0]['kp_3d'][0])
    pred_cam, pred_verts_con, pred_pose, pred_betas, pred_joints3d, smpl_joints2d, norm_joints2d = [], [], [], [], [], [], []
    pred_cam.append(
        preds[-1]['theta'][:, :, :3].reshape(preds[-1]['theta'].shape[0] * seqlen, -1).cpu())
    pred_verts_con.append(
        preds[-1]['verts'].reshape(preds[-1]['verts'].shape[0] * seqlen, -1, 3).cpu())
    pred_pose.append(
        preds[-1]['theta'][:, :, 3:75].reshape(preds[-1]['theta'].shape[0] * seqlen, -1).cpu())
    pred_betas.append(
        preds[-1]['theta'][:, :, 75:].reshape(preds[-1]['theta'].shape[0] * seqlen, -1).cpu())
    pred_joints3d.append(
        preds[-1]['kp_3d'].reshape(preds[-1]['kp_3d'].shape[0] * seqlen, -1, 3).cpu())
    smpl_joints2d.append(
        preds[-1]['kp_2d'].reshape(preds[-1]['kp_2d'].shape[0] * seqlen, -1, 2).cpu())

    renderer = Renderer(resolution=(256, 256), orig_img = True, wireframe = False)

    pred_cam = torch.cat(pred_cam, dim=0)
    pred_verts_con = torch.cat(pred_verts_con, dim=0)
    pred_pose = torch.cat(pred_pose, dim=0)
    pred_betas = torch.cat(pred_betas, dim=0)
    pred_joints3d = torch.cat(pred_joints3d, dim=0)
    smpl_joints2d = torch.cat(smpl_joints2d, dim=0)

    pred_cam = pred_cam.detach().numpy()
    pred_verts_con = pred_verts_con.detach().numpy()
    pred_pose = pred_pose.detach().numpy()
    pred_betas = pred_betas.detach().numpy()
    pred_joints3d = pred_joints3d.detach().numpy()
    smpl_joints2d = smpl_joints2d.detach().numpy()

    orig_cam = convert_crop_cam_to_orig_img(
        cam=pred_cam,
        # bbox=list(self.test_loader.dataset.db['bbox'][i]),
        bbox=[128, 128, 256, 256],
        img_width=256,
        img_height=256
    )
    output_dict = {
        'pred_cam': pred_cam,
        'orig_cam': orig_cam,
        'verts': pred_verts_con,
        'pose': pred_pose,
        'betas': pred_betas,
        'joints3d': pred_joints3d,
        # 'joints2d': joints2d,
        # 'joints2d_img_coord': joints2d_img_coord,
        # 'bboxes': self.test_loader.dataset.db['bbox'][i].reshape(1,4),
        'bboxes': np.array([128, 128, 256, 256]).reshape(1, 4),
        'frame_ids': pred_cam.shape[0],
    }
    vibe_results['0'] = output_dict
    frame_results = prepare_rendering_results(vibe_results, pred_cam.shape[0])
    mesh_color = {k: colorsys.hsv_to_rgb(np.random.rand(), 0.5, 1.0) for k in vibe_results.keys()}
    image_file_names = image_name.tolist()
    for index in tqdm(range(len(bbox[0]))):
        # joints2d_img_coord = convert_crop_coords_to_orig_img(
        #     bbox=bbox[0][index].detach().numpy().reshape(1, 4),  # bbox=np.array([1024,1024,2048,2048]).reshape(1,4),
        #     keypoints=smpl_joints2d,
        #     crop_size=256,
        # )

        # #
        # img_fname = 'F' + image_name[index][1:]
        # img = cv2.imread(img_fname)
        # frame_verts = preds[0]['verts'][:,index,:,:]
        # frame_cam = orig_cam



        # image_file_names = [
        #     x + '.jpg'
        #     for x in image_folder  # for x in os.listdir(image_folder)#这个地方是5500，它应该不对
        #     # if image_folder.index(x) in self.test_loader.dataset.db['valid_i']
        # ]
        # for frame_idx in tqdm(range(len(image_file_names))):

        # img_fname_con = 'F' + image_file_names[index][1:]
        # img_fname_con_part = img_fname_con.split('\\')
        # img_fname = img_fname_con_part[0]+ "\\MPI-INF-3DHP(beifen_mask)"+'\\'+img_fname_con_part[3]+'\\'+img_fname_con_part[4]

        img_fname = 'F' + image_file_names[index][1:]
        # img = cv2.LoadImage(img_fname, 0)
        # size = (img.width,img.height)

        img = cv2.imread(img_fname)
        img = cv2.flip(img, 1)
        # img = Image.open(img_fname)
        height_color, width_color, channels_color = img.shape
        # invert_image = np.ones_like(img)*255
        # img = invert_image - img*2.2
        # for row in range(height_color):
        #     for col in range(width_color):
        #         for chan in range(channels_color):
        #             point = img[row, col, chan]
        #             img[row, col, chan] = 255 - point*0.2


        # if True:  # if args.sideview:
        #     side_img = np.zeros_like(img)
        for person_id, person_data in frame_results[index].items():
            frame_verts = person_data['verts']
            # person_data['verts']
            frame_cam = person_data['cam']
            mc = mesh_color[person_id]
            mesh_filename = None
            # if args.save_obj:
            #     mesh_folder = os.path.join(output_path, 'meshes', f'{person_id:04d}')
            #     os.makedirs(mesh_folder, exist_ok=True)
            #     mesh_filename = os.path.join(mesh_folder, f'{frame_idx:06d}.obj')


            # #使用kp_3d中的值来替换verts中的所有值
            # joints_verts = frame_verts.copy()
            # # joints_con = preds[0]['kp_3d'][0][index]
            # joints_con = targ_pose[0][index]
            # for index1 in range(0,len(frame_verts),len(joints_con)):
            #     if(index1+len(joints_con) <= len(frame_verts)):
            #         joints_verts[index1:index1+len(joints_con),:] = joints_con[index1%len(joints_con),:].cpu().detach().numpy()
            #     else:
            #         joints_verts[index1:index1 + len(frame_verts), :] = joints_con[
            #             :len(frame_verts)-index1,:].cpu().detach().numpy()
            #
            # joints_verts[:,0] = joints_verts[:,0]*1.6
            # joints_verts[:, 1] = joints_verts[:, 1]*1.2



            # img = renderer.render(
            #     img,
            #     # frame_verts,
            #     joints_verts,
            #     cam=frame_cam,
            #     color=mc,
            #     mesh_filename=mesh_filename,
            # )
            # if True:  # if args.sideview:
            #     side_img = renderer.render(
            #         side_img,
            #         # frame_verts,
            #         joints_verts,
            #         cam=frame_cam,
            #         color=mc,
            #         mesh_filename=mesh_filename,
            #     )
            #     side_img = (side_img!=0).astype(np.int32)
            #     img = img * side_img
            #     side_img = renderer.render(
            #         side_img,
            #         # frame_verts,
            #         joints_verts,
            #         cam=frame_cam,
            #         color=mc,
            #         angle=270,
            #         axis=[0, 1, 0],
            #     )
            # cv2.imshow('origin_image', img)  # 自己添加的,这里的img图为原始的当前帧
            # cv2.imshow('render_image', side_img)  # 自己添加的


            # cv2.imwrite(os.path.join('C:\\Users\\Administrator\\Desktop', 'www.png'), img)
            # img.save('C:\\Users\\Administrator\\Desktop\\www.png')
            # norm_img1 = cv2.normalize(img, None, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
            # norm_img1 = (255 * norm_img1).astype(np.uint8)


            # cv2.imwrite(os.path.join('C:\\Users\\Administrator\\Desktop', 'aaa.png'), image_contrasted)
            # image_contrasted.save('C:\\Users\\Administrator\\Desktop\\aaa.png')


            # cv2.imwrite(img_fname[:-4]+'_enhancement'+img_fname[-4:], norm_img1)

            img_fname_part = img_fname.split('\\')[2]+'_enhancement'
            img_fname = img_fname.split('\\')[0] +'\\'+ img_fname.split('\\')[1] +'\\'+ img_fname_part +'\\'+ img_fname.split('\\')[3] +'\\'+ img_fname.split('\\')[4]
            cv2.imwrite(img_fname, img)
            # img_fname_part = img_fname.split('\\')[1] + '_enhancement'
            # img_fname = img_fname.split('\\')[0] + '\\' + img_fname_part + '\\' +img_fname.split('\\')[2] + '\\' + img_fname.split('\\')[3]
            # enh_con = ImageEnhance.Contrast(img)
            # image_contrasted = enh_con.enhance(1.8)
            # image_contrasted.save(img_fname)
    print(image_name[0])
    print(image_name[len(image_name)-1])

            # if args.sideview:
            #     img = np.concatenate([img, side_img], axis=1)
            # cv2.imwrite(os.path.join(output_img_folder, f'{frame_idx:06d}.png'), img)
            # if True:#if args.display:
            #     cv2.namedWindow('Video',cv2.WINDOW_NORMAL)
            #     cv2.imshow('Video', img)
            #     if cv2.waitKey(1) & 0xFF == ord('q'):
            #         break
        # mc = mesh_color[index]
        # img = renderer.render(
        #     img,
        #     frame_verts,
        #     cam=frame_cam,
        #     color=mc,
        #     mesh_filename=None,
        # )
    # print()

def camera_to_world_frame(x, R, T):
    """
    Args
        x: Nx3 points in camera coordinates#这里输入的x其实是相机坐标
        R: 3x3 Camera rotation matrix
        T: 3x1 Camera translation parameters
    Returns
        xcam: Nx3 points in world coordinates
    """
    devices = torch.device('cuda')
    R = torch.tensor(torch.as_tensor(R, device='cuda'), dtype=torch.float32)
    T = torch.tensor(torch.as_tensor(T, device='cuda'), dtype=torch.float32)
    x = torch.tensor(torch.as_tensor(x, device='cuda'), dtype=torch.float32)
    xcam = torch.mm(torch.t(R), torch.t(x))  # 原本是xcam = torch.mm(torch.t(R), torch.t(x))
    xcam = torch.t(xcam)# + T  # rotate and translate
    return xcam

def _natural_key(string_):
    return [int(s) if s.isdigit() else s for s in re.split(r'(\d+)', string_.lower())]


def _rescan_model_configs():
    global _MODEL_CONFIGS

    config_ext = ('.json',)
    config_files = []
    for config_path in _MODEL_CONFIG_PATHS:
        if config_path.is_file() and config_path.suffix in config_ext:
            config_files.append(config_path)
        elif config_path.is_dir():
            for ext in config_ext:
                config_files.extend(config_path.glob(f'*{ext}'))

    for cf in config_files:
        with open(cf, 'r') as f:
            model_cfg = json.load(f)
            if all(a in model_cfg for a in ('embed_dim', 'vision_cfg', 'text_cfg')):
                _MODEL_CONFIGS[cf.stem] = model_cfg

    _MODEL_CONFIGS = {k: v for k, v in sorted(_MODEL_CONFIGS.items(), key=lambda x: _natural_key(x[0]))}


_rescan_model_configs()  # initial populate of model config registry


def list_models():
    """ enumerate available model architectures based on config files """
    return list(_MODEL_CONFIGS.keys())


def add_model_config(path):
    """ add model config path or file and update registry """
    if not isinstance(path, Path):
        path = Path(path)
    _MODEL_CONFIG_PATHS.append(path)
    _rescan_model_configs()


def get_model_config(model_name):
    if model_name in _MODEL_CONFIGS:
        return deepcopy(_MODEL_CONFIGS[model_name])
    else:
        return None


def get_tokenizer(model_name):
    if model_name.startswith(HF_HUB_PREFIX):
        tokenizer = HFTokenizer(model_name[len(HF_HUB_PREFIX):])
    else:
        config = get_model_config(model_name)
        tokenizer = HFTokenizer(config['text_cfg']['hf_tokenizer_name']) if 'hf_tokenizer_name' in config['text_cfg'] else tokenize
    return tokenizer


def load_state_dict(checkpoint_path: str, map_location='cpu'):
    checkpoint = torch.load(checkpoint_path, map_location=map_location)
    if isinstance(checkpoint, dict) and 'state_dict' in checkpoint:
        state_dict = checkpoint['state_dict']
    else:
        state_dict = checkpoint
    if next(iter(state_dict.items()))[0].startswith('module'):
        state_dict = {k[7:]: v for k, v in state_dict.items()}
    return state_dict


def load_checkpoint(model, checkpoint_path, strict=True):
    state_dict = load_state_dict(checkpoint_path)
    # detect old format and make compatible with new format
    if 'positional_embedding' in state_dict and not hasattr(model, 'positional_embedding'):
        state_dict = convert_to_custom_text_state_dict(state_dict)
    resize_pos_embed(state_dict, model)
    incompatible_keys = model.load_state_dict(state_dict, strict=strict)
    return incompatible_keys

def checkpoint2model(checkpoint, key='gen_state_dict'):
    state_dict = checkpoint[key]
    print(f'Performance of loaded model on 3DPW is {checkpoint["performance"]:.2f}mm')
    # del state_dict['regressor.mean_theta']
    return state_dict
def batch_encoder_disc_l2_loss(disc_value):
    '''
        Inputs:
            disc_value: N x 25
    '''
    k = disc_value.shape[0]
    return torch.sum((disc_value - 1.0) ** 2) * 1.0 / k


def batch_adv_disc_l2_loss(real_disc_value, fake_disc_value):
    '''
        Inputs:
            disc_value: N x 25
    '''
    ka = real_disc_value.shape[0]
    kb = fake_disc_value.shape[0]
    lb, la = torch.sum(fake_disc_value ** 2) / kb, torch.sum((real_disc_value - 1) ** 2) / ka
    return la, lb, la + lb

def get_optimizer(model, optim_type, lr, weight_decay, momentum):
    if optim_type in ['sgd', 'SGD']:
        opt = torch.optim.SGD(lr=lr, params=model.parameters(), momentum=momentum)
    elif optim_type in ['Adam', 'adam', 'ADAM']:
        opt = torch.optim.Adam(lr=lr, params=model.parameters(), weight_decay=weight_decay)
    else:
        raise ModuleNotFoundError
    return opt


def create_model(
        model_name: str,
        pretrained: Optional[str] = None,
        precision: str = 'fp32',
        device: Union[str, torch.device] = 'cpu',
        jit: bool = False,
        force_quick_gelu: bool = False,
        force_custom_text: bool = False,
        force_patch_dropout: Optional[float] = None,
        force_image_size: Optional[Union[int, Tuple[int, int]]] = None,
        pretrained_image: bool = False,
        pretrained_hf: bool = True,
        cache_dir: Optional[str] = None,
        output_dict: Optional[bool] = None,
):
    # has_hf_hub_prefix = model_name.startswith(HF_HUB_PREFIX)
    # if has_hf_hub_prefix:
    #     model_id = model_name[len(HF_HUB_PREFIX):]
    #     checkpoint_path = download_pretrained_from_hf(model_id, cache_dir=cache_dir)
    #     config_path = download_pretrained_from_hf(model_id, filename='open_clip_config.json', cache_dir=cache_dir)
    #
    #     with open(config_path, 'r', encoding='utf-8') as f:
    #         config = json.load(f)
    #     pretrained_cfg = config['preprocess_cfg']
    #     model_cfg = config['model_cfg']
    # else:
    #     model_name = model_name.replace('/', '-')  # for callers using old naming with / in ViT names
    #     checkpoint_path = None
    #     pretrained_cfg = {}
    #     model_cfg = None

    device = torch.device(device)

    # if pretrained and pretrained.lower() == 'openai':
    #     logging.info(f'Loading pretrained {model_name} from OpenAI.')
    #     model = load_openai_model(
    #         model_name,
    #         precision=precision,
    #         device=device,
    #         jit=jit,
    #         cache_dir=cache_dir,
    #     )
    # else:
    #     model_cfg = model_cfg or get_model_config(model_name)
    #     if model_cfg is not None:
    #         logging.info(f'Loaded {model_name} model config.')
    #     else:
    #         logging.error(f'Model config for {model_name} not found; available models {list_models()}.')
    #         raise RuntimeError(f'Model config for {model_name} not found.')
    #
    #     if force_quick_gelu:
    #         # override for use of QuickGELU on non-OpenAI transformer models
    #         model_cfg["quick_gelu"] = True
    #
    #     if force_patch_dropout is not None:
    #         # override the default patch dropout value
    #         model_cfg["vision_cfg"]["patch_dropout"] = force_patch_dropout
    #
    #     if force_image_size is not None:
    #         # override model config's image size
    #         model_cfg["vision_cfg"]["image_size"] = force_image_size
    #
    #     if pretrained_image:
    #         if 'timm_model_name' in model_cfg.get('vision_cfg', {}):
    #             # pretrained weight loading for timm models set via vision_cfg
    #             model_cfg['vision_cfg']['timm_model_pretrained'] = True
    #         else:
    #             assert False, 'pretrained image towers currently only supported for timm models'
    #
    #     cast_dtype = get_cast_dtype(precision)
    #     is_hf_model = 'hf_model_name' in model_cfg.get('text_cfg', {})
    #     custom_text = model_cfg.pop('custom_text', False) or force_custom_text or is_hf_model

        # if custom_text:
        #     if is_hf_model:
        #         model_cfg['text_cfg']['hf_model_pretrained'] = pretrained_hf
        #     if "coca" in model_name:
        #         model = CoCa(**model_cfg, cast_dtype=cast_dtype)
        #     else:
        #         model = CustomTextCLIP(**model_cfg, cast_dtype=cast_dtype)
        # else:
        # config_path = download_pretrained_from_hf(model_id, filename='open_clip_config.json', cache_dir=cache_dir)
        # with open(config_path, 'r', encoding='utf-8') as f:
        #     config = json.load(f)
        # model_cfg = config['model_cfg']
        # model_cfg = model_cfg or get_model_config(model_name)
    model = CLIP()#, cast_dtype=cast_dtype)

        # if pretrained:
        #     checkpoint_path = ''
        #     pretrained_cfg = get_pretrained_cfg(model_name, pretrained)
        #     if pretrained_cfg:
        #         checkpoint_path = download_pretrained(pretrained_cfg, cache_dir=cache_dir)
        #     elif os.path.exists(pretrained):
        #         checkpoint_path = pretrained
        #
        #     if checkpoint_path:
        #         logging.info(f'Loading pretrained {model_name} weights ({pretrained}).')
        #         load_checkpoint(model, checkpoint_path)
        #     else:
        #         error_str = (
        #             f'Pretrained weights ({pretrained}) not found for model {model_name}.'
        #             f'Available pretrained tags ({list_pretrained_tags_by_model(model_name)}.')
        #         logging.warning(error_str)
        #         raise RuntimeError(error_str)
        # elif has_hf_hub_prefix:
        #     logging.info(f'Loading pretrained {model_name} weights ({pretrained}).')
        #     load_checkpoint(model, checkpoint_path)

    model.to(device=device)
        # if precision in ("fp16", "bf16"):
        #     convert_weights_to_lp(model, dtype=torch.bfloat16 if precision == 'bf16' else torch.float16)
        #
        # # set image / mean metadata from pretrained_cfg if available, or use default
        # model.visual.image_mean = pretrained_cfg.get('mean', None) or OPENAI_DATASET_MEAN
        # model.visual.image_std = pretrained_cfg.get('std', None) or OPENAI_DATASET_STD

        # to always output dict even if it is clip
        # if output_dict and hasattr(model, "output_dict"):
        #     model.output_dict = True
        #
        # if jit:
        #     model = torch.jit.script(model)

    return model


def create_loss(args):
    if "coca" in args.model.lower():
        return CoCaLoss(
            caption_loss_weight=args.coca_caption_loss_weight,
            clip_loss_weight=args.coca_contrastive_loss_weight,
            local_loss=args.local_loss,
            gather_with_grad=args.gather_with_grad,
            cache_labels=True,
            rank=args.rank,
            world_size=args.world_size,
            use_horovod=args.horovod,
        )
    return ClipLoss(
        local_loss=args.local_loss,
        gather_with_grad=args.gather_with_grad,
        cache_labels=True,
        rank=args.rank,
        world_size=args.world_size,
        use_horovod=args.horovod,
    )


def create_model_and_transforms(
        model_name: str,
        pretrained: Optional[str] = None,
        precision: str = 'fp32',
        device: Union[str, torch.device] = 'cpu',
        jit: bool = False,
        force_quick_gelu: bool = False,
        force_custom_text: bool = False,
        force_patch_dropout: Optional[float] = None,
        force_image_size: Optional[Union[int, Tuple[int, int]]] = None,
        pretrained_image: bool = False,
        pretrained_hf: bool = True,
        image_mean: Optional[Tuple[float, ...]] = None,
        image_std: Optional[Tuple[float, ...]] = None,
        aug_cfg: Optional[Union[Dict[str, Any], AugmentationCfg]] = None,
        cache_dir: Optional[str] = None,
        output_dict: Optional[bool] = None,
):
    model = create_model(
        model_name,
        pretrained,
        precision=precision,
        device=device,
        jit=jit,
        force_quick_gelu=force_quick_gelu,
        force_custom_text=force_custom_text,
        force_patch_dropout=force_patch_dropout,
        force_image_size=force_image_size,
        pretrained_image=pretrained_image,
        pretrained_hf=pretrained_hf,
        cache_dir=cache_dir,
        output_dict=output_dict,
    )

    # image_mean = image_mean or getattr(model.visual, 'image_mean', None)
    # image_std = image_std or getattr(model.visual, 'image_std', None)
    # preprocess_train = image_transform(
    #     model.visual.image_size,
    #     is_train=True,
    #     mean=image_mean,
    #     std=image_std,
    #     aug_cfg=aug_cfg,
    # )
    # preprocess_val = image_transform(
    #     model.visual.image_size,
    #     is_train=False,
    #     mean=image_mean,
    #     std=image_std,
    # )

    return model#, preprocess_train, preprocess_val


def create_model_from_pretrained(
        model_name: str,
        pretrained: str,
        precision: str = 'fp32',
        device: Union[str, torch.device] = 'cpu',
        jit: bool = False,
        force_quick_gelu: bool = False,
        force_custom_text: bool = False,
        force_image_size: Optional[Union[int, Tuple[int, int]]] = None,
        return_transform: bool = True,
        image_mean: Optional[Tuple[float, ...]] = None,
        image_std: Optional[Tuple[float, ...]] = None,
        cache_dir: Optional[str] = None,
):
    # if not is_pretrained_cfg(model_name, pretrained) and not os.path.exists(pretrained):
    #     raise RuntimeError(
    #         f'{pretrained} is not a valid pretrained cfg or checkpoint for {model_name}.'
    #         f' Use open_clip.list_pretrained() to find one.')

    model = create_model(
        model_name,
        pretrained,
        precision=precision,
        device=device,
        jit=jit,
        force_quick_gelu=force_quick_gelu,
        force_custom_text=force_custom_text,
        force_image_size=force_image_size,
        cache_dir=cache_dir,
    )

    # if not return_transform:
    #     return model
    #
    # image_mean = image_mean or getattr(model.visual, 'image_mean', None)
    # image_std = image_std or getattr(model.visual, 'image_std', None)
    # preprocess = image_transform(
    #     model.visual.image_size,
    #     is_train=False,
    #     mean=image_mean,
    #     std=image_std,
    # )

    return model#, preprocess
